<?php

require __DIR__ . '/vendor/autoload.php';

use Twilio\Rest\Client;

$account_sid    = 'AC6007c14d1abad7d4a552681f8b7c066e';
$auth_token  = '0a9f116bf257d88c4601ffbc1d31358e';

$twilio_number = "+15087090235";

$client = new Client($account_sid, $auth_token);

$client->messages->create(
    // Where to send a text message (your cell phone?)
    '+201094586906‬',
    array(
        'from' => $twilio_number,
        'body' => 'I sent this message in under 10 minutes!'
    )
);