<?php 
 
// Update the path below to your autoload.php, 
// see https://getcomposer.org/doc/01-basic-usage.md 
require_once './vendor/autoload.php'; 
 
use Twilio\Rest\Client; 
 
$sid    = "AC84542b45b669b220b634c8362478d683"; 
$token  = "30b84d89a1edc42e0e4d7fc92142d3d3"; 
$twilio = new Client($sid, $token); 

//saved numbers to twilio
// ‭+201094586906‬ -- habiba hegazy
// +201091087609 -- yousef hatem
// ‭+201201815059‬ -- seif el mosalamy
// +201143507334 -- sara fouad

 
$message = $twilio->messages 
                  ->create("whatsapp:+201091087609", // to 
                           array( 
                               "from" => "whatsapp:+14155238886",       
                               "body" => "ya ostaz" 
                           ) 
                  ); 
 
print($message->sid);