<?php
require 'sendgrid/vendor/autoload.php'; 

// If you're using Composer (recommended)
// Comment out the above line if not using Composer
// require("<PATH TO>/sendgrid-php.php");
// If not using Composer, uncomment the above line and
// download sendgrid-php.zip from the latest release here,
// replacing <PATH TO> with the path to the sendgrid-php.php file,
// which is included in the download:
// https://github.com/sendgrid/sendgrid-php/releases

$email = new \SendGrid\Mail\Mail(); 
$email->setFrom("water.foundation.egypt@gmail.com", "Water Foundation");
$tos = [ 
    "habiba.hhegazy1998@gmail.com" => "Habiba Gmail",
    "habiba1611146@miuegypt.edu.eg" => "Habiba MIU",
];
$email->addTos($tos);
$email->setSubject("Sending with Twilio SendGrid is Fun");
$email->addContent("text/plain", "This is a sendGrid Email");
$email->addContent(
    "text/html", "<strong> Thanks for being a part of the company </strong>"
);

// Attachments
/*  $file_encoded = base64_encode(file_get_contents('my_file.txt'));
$email->addAttachment(
    $file_encoded,
    "application/text",
    "my_file.txt",
    "attachment"
); */

$apiKey = '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';

$sendgrid = new \SendGrid($apiKey);
try {
    $response = $sendgrid->send($email);
    print $response->statusCode() . "\n";
    print_r($response->headers());
    print $response->body() . "\n";
} catch (Exception $e) {
    echo 'Caught exception: '.  $e->getMessage(). "\n";
}