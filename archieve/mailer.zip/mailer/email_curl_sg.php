<?php

    $email = 'habiba.hhegazy1998@gmail.com';
    $name = 'habiba hegazy';
    $subject = 'test email';
    $body = 'hello hi';

    $headers = array(
        'Authorization: Bearer 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',
        'Content-Type: application/json'
    );

    $data = array(
        'personalizations' => array(
            array(
                'to' => array(
                    array(
                        'email' => 'habiba1611146@miuegypt.edu.eg',
                        'name' => $name
                    )
                )
            )
        ),
        'from' => array(
            'email' => $email
        ),
        'subject' => $subject,
        'content' => array(
            array(
                'type' => 'text/plain',
                'value' => $body
            )
        )

    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.sendgrid.com/v3/mail/send');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec($ch);

    echo $response;


