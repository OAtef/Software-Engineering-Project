<?php
	// Account details

	// water foundation -- NtFJwGbiDXI-tPo0xaAdRq6QTZzylryftE7lvBDwzc
	// xY8K2qjXN7I-AdrTNfDLwc7gWwmmpqlXi1rVUC9A7J
	$apiKey = urlencode('NtFJwGbiDXI-tPo0xaAdRq6QTZzylryftE7lvBDwzc');
	
	// Message details
	$numbers = array(201143507334, 201094586906); // database
	$sender = urlencode('programic sms');
	$message = rawurlencode('Hello'); // html
 
	$numbers = implode(',', $numbers);
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.txtlocal.com/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
	// Process your response here
	echo $response;
	print_r($response);
	
?>